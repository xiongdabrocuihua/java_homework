import java.util.Scanner;

public class BattleEngine {
    //扫描器:接收控制台输入
    private static final Scanner scanner = new Scanner(System.in);
    public static void main(String[] args){
        Character player = new Player("玩家",40,15,7,3);
        Character enemy = new Enemy("敌人",20,0,4,1);

        // 2. 给玩家背包添加初始道具（测试用）
        initPlayerInventory((Player) player);

        //显示双方状态
        player.displayStatus();
        enemy.displayStatus();

        //战斗流程
        System.out.println("===== 战斗开始 =====");
        System.out.println("可用命令：");
        System.out.println("→ attack:普通攻击(消耗回合)");
        System.out.println("→ spell:法术攻击(消耗MP+回合)");
        System.out.println("→ status:查看状态(不消耗回合)");
        System.out.println("→ potion:使用道具(不消耗回合)");
        System.out.println("====================");

        //敌人攻击玩家
        while (player.isAlive() && enemy.isAlive()) {
            // ---- 玩家回合 ----
            playerTurn(player, enemy);
            
            // 玩家攻击后，若敌人已死亡，直接结束循环
            if (!enemy.isAlive()) {
                break;
            }

            // ---- 敌人回合 ----
            enemyTurn(player, enemy);
        }

        // 3. 战斗结束：输出结果
        endBattle(player, enemy);
        scanner.close(); // 关闭扫描器
    }

    /**
     * 初始化玩家背包（添加测试道具）
     */
    private static void initPlayerInventory(Player player) {
        Inventory inventory = player.getInventory();
        inventory.addItem(new HealthPotion()); // 生命药水
        inventory.addItem(new ManaPotion());   // 法力药水
        inventory.addItem(new DefensePotion());// 防御药水
        inventory.addItem(new HealthPotion()); // 额外生命药水
    }




    /**
     * 玩家回合：接收控制台命令，执行攻击/查看状态
     */
    private static void playerTurn(Character player, Character enemy) {
        System.out.println("\n===== 你的回合 =====");
        boolean isTurnEnd = false;

        // 循环接收命令，直到输入有效指令
        while (!isTurnEnd) {
            System.out.print("请输入命令:");
            String command = scanner.nextLine().trim().toLowerCase(); // 转小写，忽略大小写
            // 执行玩家指令
            switch (command) {
                case "attack":
                    // 普通攻击：执行后结束玩家回合
                    player.attack(enemy);
                    isTurnEnd = true;
                    break;
                case "spell":
                    // 法术攻击：释放成功才结束回合，失败则继续
                    if (((Player) player).castSpell(enemy)) {
                        isTurnEnd = true;
                    }
                    break;
                case "status":
                    // 查看状态：不结束回合，继续输入命令
                    player.displayStatus();
                    enemy.displayStatus();
                    break;
                case "potion":
                    // 使用道具：不消耗回合
                    usePotion((Player) player);
                    break;
                default:
                    System.out.println("无效命令！请输入 attack / spell / status / potion");
            }
        }
    }

    /**
     * 使用道具：显示背包→选择索引→使用道具
     */
    private static void usePotion(Player player) {
        Inventory inventory = player.getInventory();
        // 显示背包道具
        inventory.displayItems();

        // 背包为空则直接返回
        if (inventory.getItemCount() == 0) {
            return;
        }

        // 输入道具索引（容错处理）
        System.out.print("请输入要使用的道具索引：");
        String indexInput = scanner.nextLine().trim();
        int index;
        try {
            index = Integer.parseInt(indexInput);
        } catch (NumberFormatException e) {
            System.out.println("请输入有效的数字索引！");
            return;
        }

        // 使用道具
        inventory.useItem(index, player);
    }

    /**
     * 敌人回合：自动攻击玩家
     */
    private static void enemyTurn(Character player, Character enemy) {
        System.out.println("\n===== 敌人回合 =====");
        enemy.attack(player); // 敌人自动攻击玩家
    }

    /**
     * 战斗结束：输出最终结果
     */
    private static void endBattle(Character player, Character enemy) {
        System.out.println("\n===== 战斗结束 =====");
        if (player.isAlive() && !enemy.isAlive()) {
            System.out.printf("[胜利] 你击败了 %s!%n", enemy.getName());
        } else if (!player.isAlive() && enemy.isAlive()) {
            System.out.printf("[失败] 你被 %s 击败了!%n", enemy.getName());
        } else {
            System.out.println("[平局] 双方同归于尽!");
        }
    }
}
