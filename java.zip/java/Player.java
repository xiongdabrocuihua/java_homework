public class Player extends Character{
    //法术消耗mp
    private static final int SPELL_MP_COST = 5;
    // 背包属性
    private Inventory inventory;
    // 临时防御（防御药水效果）
    private int tempDefense;
    // 临时防御剩余回合
    private int tempDefenseTurns;

    public Player(String name, int hp, int mp, int attack, int defense){
        super(name,hp,mp,attack,defense);
        this.inventory = new Inventory(); // 初始化背包
        this.tempDefense = 0;
        this.tempDefenseTurns = 0;
    }

    //重写防御值，考虑临时防御
    @Override
    public int getDefense() {
        return super.getDefense() + tempDefense;
    }

    //显示玩家状态
    @Override
    public void displayStatus(){
        System.out.printf("=== 玩家状态 ===%n");
        System.out.printf("姓名：%s%n",getName());
        System.out.printf("生命值：%d%n",getHp());
        System.out.printf("法力值：%d%n",getMp());
        System.out.printf("攻击力：%d | 防御力：%d%n", getAttack(), getDefense());
    }

    //释放法术
    public boolean castSpell(Character target){
        if(getMp() < SPELL_MP_COST){
            System.out.printf("法力值不足！释放法术需要%d点MP,当前仅%d点%n",SPELL_MP_COST,getMp());
            return false;
        }

        // 消耗MP
        setMp(getMp() - SPELL_MP_COST);
        // 计算法术伤害（攻击力×1.5，最低1点）
        int spellDmg = (int) (getAttack() * 1.5);
        int actualDmg = Math.max(1, spellDmg - target.getDefense());

        // 执行法术攻击
        System.out.printf("%s 释放法术！消耗%d点MP 剩余%d点MP%n", getName(), SPELL_MP_COST, getMp());
        System.out.printf("%s 受到 %d 点法术伤害！剩余生命值：%d%n", target.getName(), actualDmg, Math.max(0, target.getHp() - actualDmg));
        target.setHp(Math.max(0, target.getHp() - actualDmg));
        return true;
    }

    // Getter & Setter
    public Inventory getInventory() {
        return inventory;
    }

    public int getTempDefense() {
        return tempDefense;
    }

    public void setTempDefense(int tempDefense) {
        this.tempDefense = tempDefense;
    }

    public int getTempDefenseTurns() {
        return tempDefenseTurns;
    }

    public void setTempDefenseTurns(int tempDefenseTurns) {
        this.tempDefenseTurns = tempDefenseTurns;
    }
}
